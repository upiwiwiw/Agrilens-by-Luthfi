package com.example.capstone.view.bookmark

data class Bookmark(
    val title: String,
    val diagnose: String,
    val thumbnail: String,
    val treatment: String,

)
